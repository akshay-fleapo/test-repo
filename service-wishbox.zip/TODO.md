## AUTH MODULE

    - [x] [POST]        /send-otp
    - [x] [POST]        /verify-otp
    - [x] [GET]         /logout
    - [x] [GET]         /
