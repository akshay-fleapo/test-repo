## REST endpoints doc

https://fleapoco.postman.co/workspace/Swishlist~e43cc5d7-58dc-493e-ba02-9755e6b5c718/collection/26394357-9f192ec3-3c4e-4671-9407-737a0dfd9403?action=share&creator=26394357

## REST

- auth only

## GQL

- domain/graphql
