export interface IJwtPayload {
  id: string;
  jti: string;
}
