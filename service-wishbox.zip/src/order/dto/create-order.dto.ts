import { Field, InputType } from '@nestjs/graphql';
import { IsNotEmpty, IsString, IsUUID } from 'class-validator';
import { gift_as, order_status, order_type, payment_status } from '../entity/order.entity';

@InputType()
export class CreateOrderDto {
  @Field()
  @IsNotEmpty()
  @IsString()
  total: number;

  @Field()
  @IsNotEmpty()
  @IsString()
  slug: string;

  @Field()
  @IsNotEmpty()
  @IsString()
  url: string;

  @Field()
  @IsNotEmpty()
  status: order_status;

  @Field()
  @IsNotEmpty()
  payment_status: payment_status;

  @Field()
  @IsNotEmpty()
  @IsString()
  payment_menthod: string;

  @Field()
  @IsNotEmpty()
  @IsString()
  stripe_payment_id: string;

  @Field()
  @IsNotEmpty()
  order_type: order_type;

  @Field()
  @IsNotEmpty()
  gift_as: gift_as;

  @Field(() => String)
  @IsUUID()
  @IsString()
  @IsNotEmpty()
  creatorId: string;

  @Field()
  @IsNotEmpty()
  @IsString()
  @IsUUID()
  address: string;
}
